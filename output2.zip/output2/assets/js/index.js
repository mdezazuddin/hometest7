$(function(){ 
      // swiper-master    
      var swiper1 = new Swiper( '.swiper1', {
        loop: true,
        slidesPerView: 1,
        autoplay: {
            delay: 5000,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          //dynamicBullets: true,
      }, 

      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      
    } );


      
    // swiper-master    
    var swiper2 = new Swiper( '.swiper2', {
      spaceBetween: 20,
      loop: true,

      autoplay: {
          delay: 5000,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
        //dynamicBullets: true,
    }, 

    navigation: {
      nextEl: '.fa-chevron-left',
      prevEl: '.fa-chevron-right',
    },
    
    // Responsive breakpoints
    breakpoints: {
      // when window width is <= 480px
      480: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      // when window width is <= 640px
      768: {
        slidesPerView: 2,
        spaceBetween: 20
      },
      // when window width is <= 640px
      992: {
        slidesPerView: 2,
        spaceBetween: 20
      }
    },  
  } );


  // swiper-master    
      var swiper3 = new Swiper( '.swiper3', {
          spaceBetween: 20,
          loop: true,

          autoplay: {
              delay: 5000,
          },
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
            //dynamicBullets: true,
        }, 

        navigation: {
          nextEl: '.fa-chevron-left',
          prevEl: '.fa-chevron-right',
        },
        
        // Responsive breakpoints
        breakpoints: {
          // when window width is <= 480px
          480: {
            slidesPerView: 1,
            spaceBetween: 20
          },
          // when window width is <= 640px
          768: {
            slidesPerView: 2,
            spaceBetween: 20
          },
          // when window width is <= 640px
          992: {
            slidesPerView: 3,
            spaceBetween: 20
          }
        },  
      } );

 });